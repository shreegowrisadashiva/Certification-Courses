
from django.contrib import admin
from django.urls import path
from hello.views import home,about,contact,reg,ureg,login,ulogin,profile
from django.conf import settings 
from django.conf.urls.static import static 

from django.contrib.staticfiles.urls  import staticfiles_urlpatterns
urlpatterns = [
    path('admin/', admin.site.urls),
    # path('greet/',greet),
    path('about/',about),
    path('contact/',contact),
    path('home/',home),
    path('reg/',reg),
    path('ureg/',ureg),
    path('login/',login),
    path('ulogin/',ulogin),
    path('profile/',profile),
    # path('uprofile/',uprofile),
    # path('search/',search),
    # path('msearch/',msearch),

]
urlpatterns += staticfiles_urlpatterns()


